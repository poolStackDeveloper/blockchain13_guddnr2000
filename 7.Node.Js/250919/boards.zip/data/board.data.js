const boards = [
    {
        id: 1,
        user_id: "guddnr2000",
        writer: "최형욱",
        title: "250918 Express 첫걸음",
        content: "오늘은 과제가 있습니다",
        hit: 0,
        created_at: "2025-09-18",
        updated_at: "2025-09-18"
    },
    {
        id: 2,
        user_id: "guddnr2000",
        writer: "최형욱",
        title: "250918 Express 첫걸음22",
        content: "오늘은 과제가 있습니다22",
        hit: 0,
        created_at: "2025-09-18",
        updated_at: "2025-09-18"
    }
]

module.exports = boards;
const function1 = (callback) => {
    const object = {req, res}
    callback(object);
}

const callback = (req, res) => {
    
}